{ //defining scope of the variables with this visibility block

    // D&D stuff
    let x = document.getElementById("anchorRow");
    x.draggable = true;
    x.addEventListener("dragstart", dragStart); //save dragged element reference
    x.addEventListener("dragover", dragOver); // change color of reference element to red
    x.addEventListener("dragleave", dragLeave); // change color of reference element to black
    x.addEventListener("drop", drop);


    // buying page
    let buyingPage = document.getElementById("buyingPage");
    let buyingAuctionsTable = null;
    let buyingAuctionsAlert = document.getElementById("buyingAuctionsAlert");
    let winningAuctionsBulletList = null;
    let wonAuctionsBulletList = null;
    let winningAuctionsAlert = document.getElementById("winningAuctionsAlert");
    let wonAuctionsAlert = document.getElementById("wonAuctionsAlert");
    let searchingForm = document.getElementById("searchingForm");
    let biddingPage = document.getElementById("biddingPage");
    let itemsBidAlert = document.querySelectorAll("itemsBidAlert");
    let itemsBiddingList = null;
    let bidsAlert = document.getElementById("bidsAlert");
    let bidList = null;
    let biddingForm = null;
    let showAllButton = document.getElementById("showAllButton");


    let startElement;

    // selling page
    let sellingPage = document.getElementById("sellingPage");
    let sellingAuctionsTable = null;
    let sellingAuctionsAlert = document.getElementById("sellingAuctionsAlert");
    let expiredAuctionsAlert = document.getElementById("expiredAuctionsAlert");
    let expiredAuctionsTable = null;
    let closedAuctionsAlert = document.getElementById("closedAuctionsAlert");
    let closedAuctionsTable = null;
    let yourItemsTable = null;
    let yourItemsAlert = document.getElementById("yourItemsAlert");
    let createItemAlert = document.getElementById("createItemAlert");
    let itemForm = null;
    let auctionForm = null;
    let auctionFormAlert = document.getElementById("auctionFormALert");
    let auctionDetailsAlert = document.getElementById("auctionDetailsAlert");
    let auctionDetailsTable = null;
    let auctionDetailsAuctionId = null;
    let auctionDetailsPage = document.getElementById("auctionDetailsPage");
    let selectedItemsBody = document.getElementById("selectedItemsTableBody");

    // links
    let sellingLink = document.getElementById("sellingLink");
    let buyingLink = document.getElementById("buyingLink");

    // startup
    sellingPage.className = "masked";
    sellingLink.className = "displayed";
    buyingLink.className = "masked";
    buyingPage.className = "displayed";
    biddingPage.className = "displayed";

    // setting the selling link onclick event listener
    sellingLink.onclick = function() {
        sellingPage.classList.remove("masked");
        sellingPage.className = "displayed";

        sellingLink.classList.remove("displayed");
        sellingLink.className = "masked";

        buyingLink.classList.remove("masked");
        buyingLink.className = "displayed";

        buyingPage.classList.remove("displayed");
        buyingPage.className = "masked";

        biddingPage.classList.remove("displayed");
        biddingPage.className = "masked";
    };

    // setting the buying link onclick event listener
    buyingLink.onclick = function() {

        sellingPage.classList.remove("displayed");
        sellingPage.className = "masked";

        sellingLink.classList.remove("masked");
        sellingLink.className = "displayed";

        buyingLink.classList.remove("displayed");
        buyingLink.className = "masked";

        buyingPage.classList.remove("masked");
        buyingPage.className = "displayed";

        biddingPage.classList.remove("displayed");
        biddingPage.className = "masked";
    };

    window.onload = function() {



        // Selling Page
        sellingAuctionsTable = new SellingAuctionsTable(
            document.getElementById("sellingAuctionsTable"),
            document.getElementById("sellingAuctionsTableBody"));
        expiredAuctionsTable = new ExpiredAuctionsTable(
            document.getElementById("expiredAuctionsTable"),
            document.getElementById("expiredAuctionsTableBody")
        );
        closedAuctionsTable = new ClosedAuctionsTable(
            document.getElementById("closedAuctionsTable"),
            document.getElementById("closedAuctionsTableBody")
        );
        yourItemsTable = new YourItemsTable(
            document.getElementById("yourItemsTable"),
            document.getElementById("yourItemsTableBody")
        );
        itemForm = new ItemForm(document.getElementById("createItemForm"));
        itemForm.registerClick();
        auctionForm = new AuctionForm(document.getElementById("createAuctionForm"));
        auctionForm.registerClick();

        sellingAuctionsTable.show();
        expiredAuctionsTable.show();
        closedAuctionsTable.show();
        yourItemsTable.show()


        // Buying Page
        searchingForm = new SearchingForm(searchingForm);
        searchingForm.registerClick();

        winningAuctionsBulletList = new WinningAuctionsBulletList(
            document.getElementById("winningAuctionsBulletList"));
        wonAuctionsBulletList = new WonAuctionsBulletList(
            document.getElementById("wonAuctionsBulletList"));
        winningAuctionsBulletList.show();
        wonAuctionsBulletList.show();
        showAllButton = new ShowAllButton(showAllButton);
        showAllButton.registerClick();

        /*// Salvataggio dei dati con un timestamp di scadenza
        var create = 1;
        var scadenza = new Date().getTime() + 30*24*60*60*1000; // Scadenza tra 1 mese

        localStorage.setItem("creazione", JSON.stringify({ value: create, expire: scadenza }));

        // Recupero dei dati e controllo della scadenza
        var toParseCreate = localStorage.getItem("creazione");
        var parsedCreate = JSON.parse(toParseCreate);*/

        var toParseCreate = localStorage.getItem("create");
        var toParseAuctions = localStorage.getItem("auctions");

        // se esistono e sono scaduti li elimino
        if (toParseCreate !== null) {
            var parsedCreate = JSON.parse(toParseCreate);
            if (parsedCreate.scadenza < new Date()) {
                localStorage.removeItem("create");
            }
        }
        if (toParseAuctions !== null) {
            var parsedAuctions = JSON.parse(toParseAuctions);
            if (parsedAuctions.scadenza < new Date()) {
                localStorage.removeItem("auctions");
            }
        }

        if (parsedAuctions && parsedAuctions.scadenza < new Date()) {
            localStorage.removeItem("auctions");
        }

        // se i dati sulla creazione ci sono e sono ancora validi
        if (toParseCreate && parsedCreate.value == 1) {

            // inizio dalla pagina vendo
            buyingPage.className = "masked";
            biddingPage.className = "masked";
            sellingPage.className = "displayed";
            auctionDetailsPage.className = "masked";
            // Links
            sellingLink.className = "masked";
            buyingLink.className = "displayed";
        } else {
            // inizio dalla pagina acquisto
            buyingPage.className = "displayed";
            biddingPage.className = "masked";
            sellingPage.className = "masked";
            auctionDetailsPage.className = "masked";

            // Links
            sellingLink.className = "displayed";
            buyingLink.className = "masked";
        }


        if (localStorage.getItem("auctions") !== null) {
            // carico le ultime aste accedute
            buyingAuctionsTable = new BuyingAuctionsTable(
                document.getElementById("buyingAuctionsTable"),
                document.getElementById("buyingAuctionsTableBody"), JSON.parse(localStorage.getItem("auctions")).auctions);
        } else {
            buyingAuctionsTable = new BuyingAuctionsTable(
                document.getElementById("buyingAuctionsTable"),
                document.getElementById("buyingAuctionsTableBody"), null);
        }

        buyingAuctionsTable.show();
        return;

    }

    function WinningAuctionsBulletList(_winningAuctionsBulletList) {
        this.winningAuctionsBulletList = _winningAuctionsBulletList;

        this.show = function() {
            let self = this;
            makeCall("GET", "LoadWinningAuctions", null,
                function(req) { //callback of the get request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let winningAuctionsToShow = JSON.parse(req.responseText);
                            if (winningAuctionsToShow.length === 0) {
                                winningAuctionsAlert.textContent = "No winning auctions yet!";
                                return;
                            }
                            self.update(winningAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                });
        }

        this.update = function(winningAuctionsToShow) {
            let bulletPoint;
            let infoRow;
            let table;
            let thead;
            let tbody;
            let row;
            let bodyRow
            let idHeader;
            let nameHeader;
            let descriptionHeader;
            let usernameHeader;
            let imageHeader;
            let priceHeader;
            let idCell;
            let nameCell;
            let descriptionCell;
            let usernameCell;
            let imageCell;
            let priceCell;


            this.winningAuctionsBulletList.innerHTML = ""; // empty the bullet list
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly
            for (let auction of winningAuctionsToShow) { // self visible in nested function by closure

                bulletPoint = document.createElement("li");

                //questa non funziona
                infoRow = document.createElement("p");
                infoRow.textContent = "Auction code: " + auction.id_code +
                    " Auction Price: " + auction.current_price +
                    " Time Left: " + auction.time_left +
                    " Seller: " + auction.username;
                bulletPoint.append(infoRow);
                //building the table
                table = document.createElement("table");
                table.style.border = "1px solid black";
                //filling table head
                thead = document.createElement("thead");

                row = document.createElement("tr");
                idHeader = document.createElement("th");
                idHeader.textContent = "id";
                row.appendChild(idHeader);


                nameHeader = document.createElement("th");
                nameHeader.textContent = "name";
                row.appendChild(nameHeader);

                descriptionHeader = document.createElement("th");
                descriptionHeader.textContent = "description";
                row.appendChild(descriptionHeader);

                usernameHeader = document.createElement("th");
                usernameHeader.textContent = "username";
                row.appendChild(usernameHeader);

                imageHeader = document.createElement("th");
                imageHeader.textContent = "image";
                row.appendChild(imageHeader);

                priceHeader = document.createElement("th");
                priceHeader.textContent = "price";
                row.appendChild(priceHeader);


                thead.appendChild(row);
                table.appendChild(thead);

                //building tbody
                tbody = document.createElement("tbody");
                auction.items.forEach(function(item) {
                    bodyRow = document.createElement("tr");

                    idCell = document.createElement("td");
                    idCell.textContent = item.id_code;
                    bodyRow.appendChild(idCell);


                    nameCell = document.createElement("td");
                    nameCell.textContent = item.name;
                    bodyRow.appendChild(nameCell);

                    descriptionCell = document.createElement("td");
                    descriptionCell.textContent = item.description;
                    bodyRow.appendChild(descriptionCell);

                    usernameCell = document.createElement("td");
                    usernameCell.textContent = item.username;
                    bodyRow.appendChild(usernameCell);

                    imageCell = document.createElement("td");
                    /*let image = document.createElement("img");
                    image.src = "data:image/png;base64," + btoa(imageData);*/
                    bodyRow.appendChild(imageCell);

                    priceCell = document.createElement("td");
                    priceCell.textContent = item.price;
                    bodyRow.appendChild(priceCell);

                    tbody.appendChild(bodyRow);
                });
                //connect everything
                table.appendChild(tbody);
                bulletPoint.appendChild(table);
                self.winningAuctionsBulletList.appendChild(bulletPoint);


            };
        }
    }

    function selectedItemsFlush() {
        var toRem = selectedItemsBody.querySelectorAll("tr");
        for (val of toRem) {
            if (val.id !== "anchorRow") {
                val.innerHTML = "";
            }
        }
    }

    function WonAuctionsBulletList(_wonAuctionsBulletList) {
        this.wonAuctionsBulletList = _wonAuctionsBulletList;

        this.show = function() {
            let self = this;
            makeCall("GET", "LoadWonAuctions", null,
                function(req) { //callback of the get request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let wonAuctionsToShow = JSON.parse(req.responseText);
                            if (wonAuctionsToShow.length === 0) {
                                wonAuctionsAlert.textContent = "No won auctions yet!";
                                return;
                            }
                            self.update(wonAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                });
        }

        this.update = function(wonAuctionsToShow) {
            let bulletPoint;
            let infoRow;
            let table;
            let thead;
            let tbody;
            let row;
            let bodyRow
            let idHeader;
            let nameHeader;
            let descriptionHeader;
            let usernameHeader;
            let imageHeader;
            let priceHeader;
            let idCell;
            let nameCell;
            let descriptionCell;
            let usernameCell;
            let imageCell;
            let priceCell;


            this.wonAuctionsBulletList.innerHTML = ""; // empty the bullet list
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly
            for (let key in wonAuctionsToShow) { // self visible in nested function by closure

                let value = wonAuctionsToShow[key];

                bulletPoint = document.createElement("li");

                // questa non funziona
                /*infoRow = document.createElement("p");
                infoRow.textContent = "auction code: " + x.id_code + 
                					+ "seller username:  " + x.username
                					+ "current price: " + x.amount;
                bulletPoint.append(infoRow);*/
                //building the table
                table = document.createElement("table");
                table.style.border = "1px solid black";
                //filling table head
                thead = document.createElement("thead");

                row = document.createElement("tr");
                idHeader = document.createElement("th");
                idHeader.textContent = "id";
                row.appendChild(idHeader);


                nameHeader = document.createElement("th");
                nameHeader.textContent = "name";
                row.appendChild(nameHeader);

                descriptionHeader = document.createElement("th");
                descriptionHeader.textContent = "description";
                row.appendChild(descriptionHeader);

                usernameHeader = document.createElement("th");
                usernameHeader.textContent = "username";
                row.appendChild(usernameHeader);

                imageHeader = document.createElement("th");
                imageHeader.textContent = "image";
                row.appendChild(imageHeader);

                priceHeader = document.createElement("th");
                priceHeader.textContent = "price";
                row.appendChild(priceHeader);


                thead.appendChild(row);
                table.appendChild(thead);

                //building tbody
                tbody = document.createElement("tbody");
                key.items.forEach(function(item) {
                    bodyRow = document.createElement("tr");

                    idCell = document.createElement("td");
                    idCell.textContent = item.id_code;
                    bodyRow.appendChild(idCell);


                    nameCell = document.createElement("td");
                    nameCell.textContent = item.name;
                    bodyRow.appendChild(nameCell);

                    descriptionCell = document.createElement("td");
                    descriptionCell.textContent = item.description;
                    bodyRow.appendChild(descriptionCell);

                    usernameCell = document.createElement("td");
                    usernameCell.textContent = item.username;
                    bodyRow.appendChild(usernameCell);

                    imageCell = document.createElement("td");
                    /*let image = document.createElement("img");
                    image.src = "data:image/png;base64," + btoa(imageData);*/
                    bodyRow.appendChild(imageCell);

                    priceCell = document.createElement("td");
                    priceCell.textContent = item.price;
                    bodyRow.appendChild(priceCell);

                    tbody.appendChild(bodyRow);
                });
                //connect everything
                table.appendChild(tbody);
                bulletPoint.appendChild(table);
                self.winningAuctionsBulletList.appendChild(bulletPoint);


            };
        }
    }

    function BuyingAuctionsTable(_buyingAuctionsContainer, _buyingAuctionsContainerBody, localStorageAuctionList) {
        this.buyingAuctionsContainer = _buyingAuctionsContainer;
        this.buyingAuctionsContainerBody = _buyingAuctionsContainerBody;
        this.localStorageAuctionList = localStorageAuctionList;
        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            if (self.localStorageAuctionList === null) {
                makeCall("GET", "LoadBuyingAuctions", null,
                    function(req) { // callback of the GET request
                        if (req.readyState === 4) {
                            if (req.status === 200) {
                                let buyingAuctionsToShow = JSON.parse(req.responseText);
                                if (buyingAuctionsToShow.length === 0) {
                                    buyingAuctionsAlert.textContent = "No auctions yet!";
                                    return;
                                }
                                self.update(buyingAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                            } else { //printing errors
                                alert(req.responseText);
                            }
                        }
                    }
                );
            } else {
                makeCallStorage("POST", "LoadStorageBuyingAuctions", localStorageAuctionList,
                    function(req) { // callback of the GET request
                        if (req.readyState === 4) {
                            if (req.status === 200) {
                                let buyingAuctionsToShow = JSON.parse(req.responseText);
                                if (buyingAuctionsToShow.length === 0) {
                                    buyingAuctionsAlert.textContent = "No auctions yet!";

                                }
                                self.update(buyingAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                            } else { //printing errors
                                alert(req.responseText);
                            }
                        }
                    }
                );
            }


        };
        this.showAll = function() {
            let self = this; // this not direcly visible in nested functions,
            makeCall("GET", "LoadBuyingAuctions", null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let buyingAuctionsToShow = JSON.parse(req.responseText);
                            if (buyingAuctionsToShow.length === 0) {
                                buyingAuctionsAlert.textContent = "No auctions yet!";
                                return;
                            }
                            self.update(buyingAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );


        };

        this.update = function(buyingAuctionsToShow) {
            let row;
            let idCodeCell;
            let minimumOffsetCell;
            let currentBidCell;
            let linktext;
            let anchor;
            let exp_dateCell;
            this.buyingAuctionsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly
            buyingAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure

                let x = auction;
                row = document.createElement("tr");

                let idCodeCell = document.createElement("td");
                idCodeCell.textContent = auction.id_code;
                row.appendChild(idCodeCell);

                let minimumOffsetCell = document.createElement("td");
                minimumOffsetCell.textContent = auction.minimum_offset;
                row.appendChild(minimumOffsetCell);

                let currentBidCell = document.createElement("td");
                currentBidCell.textContent = auction.current_price;
                row.appendChild(currentBidCell);

                exp_dateCell = document.createElement("td");
                exp_dateCell.textContent = auction.time_left;
                row.appendChild(exp_dateCell);

                idCodeCell.addEventListener("click", function() {
                    biddingPage.classList.remove("masked");
                    biddingPage.classList.add("displayed");

                    var auctionIdMessage = biddingPage.querySelector("#auctionIdMessage");
                    var minimumOffsetMessage = biddingPage.querySelector("#minimumOffsetMessage");
                    var currentPriceMessage = biddingPage.querySelector("#currentPriceMessage");
                    var minimumBidMessage = biddingPage.querySelector("#minimumBidMessage");

                    // remove the previous auction id message
                    if (auctionIdMessage.hasChildNodes()) {
                        auctionIdMessage.removeChild(auctionIdMessage.firstChild);
                    }

                    // remove the previous minimum offset message
                    if (minimumOffsetMessage.hasChildNodes()) {
                        minimumOffsetMessage.removeChild(minimumOffsetMessage.firstChild);
                    }

                    // remove the previous minimum offset message
                    if (currentPriceMessage.hasChildNodes()) {
                        currentPriceMessage.removeChild(currentPriceMessage.firstChild);
                    }

                    if (minimumBidMessage.hasChildNodes()) {
                        minimumBidMessage.removeChild(minimumBidMessage.firstChild);
                    }

                    // STRANO, MA FUNZIONA
                    auctionIdMessage.appendChild(document.createTextNode("Auction ID: " + idCodeCell.textContent));
                    currentPriceMessage.appendChild(document.createTextNode("Current Price: " + currentBidCell.textContent))
                    minimumOffsetMessage.appendChild(document.createTextNode("Minimum offset: " + minimumOffsetCell.textContent));
                    var a = parseInt(x.current_price);
                    var b = parseInt(minimumOffsetCell.textContent);
                    var c = a + b;
                    minimumBidMessage.appendChild(document.createTextNode("Minimum Bid: " + c));
                    itemsBiddingList = new ItemsTable(
                        document.getElementById("itemsBidTable"),
                        document.getElementById("itemsBidTableBody"),
                        idCodeCell.textContent
                    );
                    itemsBiddingList.show();
                    bidList = new BidsTable(
                        document.getElementById("bidTable"),
                        document.getElementById("bidTableBody"),
                        idCodeCell.textContent
                    );
                    bidList.show();
                    biddingForm = new BiddingForm(document.getElementById("biddingForm"), idCodeCell.textContent);
                    biddingForm.registerClick();


                    var toParseList = localStorage.getItem("auctions");
                    if (toParseList === null) {
                        let scadenza = new Date() /*.getTime() + 30*24*60*60*1000*/ ;
                        let temp = {
                            auctions: [idCodeCell.textContent],
                            scadenza: scadenza
                        }
                        var parsedList = JSON.stringify(temp);

                    } else {
                        let temp = JSON.parse(toParseList);
                        if (!temp.auctions.includes(idCodeCell.textContent)) {
                            temp.auctions.push(idCodeCell.textContent);
                        }
                        temp.scadenza = new Date() /*.getTime() + 30*24*60*60*1000*/ ;
                        var parsedList = JSON.stringify(temp);
                    }
                    localStorage.setItem("auctions", parsedList);
                }, false);




                self.buyingAuctionsContainerBody.appendChild(row);
            });
        };
    }

    function ItemsTable(_itemsContainer, _itemsContainerBody, id) {
        this.itemsContainer = _itemsContainer;
        this.itemsContainerBody = _itemsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "GetBidItems?auctionId=" + id, null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let itemsTableToShow = JSON.parse(req.responseText);
                            if (itemsTableToShow.length === 0) {
                                itemsBidAlert.textContent = "There are no items in this auction";
                            }
                            self.update(itemsTableToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(itemsTableToShow) {
            this.itemsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly

            itemsTableToShow.forEach(function(item) { // self visible in nested function by closure

                row = document.createElement("tr");

                idCodeCell = document.createElement("td");
                idCodeCell.textContent = item.id_code;
                row.appendChild(idCodeCell);

                nameCell = document.createElement("td");
                nameCell.textContent = item.name;
                row.appendChild(nameCell);

                priceCell = document.createElement("td");
                priceCell.textContent = item.price;
                row.appendChild(priceCell);

                imageCell = document.createElement("td");
                row.appendChild(imageCell);

                descriptionCell = document.createElement("td");
                descriptionCell.textContent = item.description;
                row.appendChild(descriptionCell);



                self.itemsContainerBody.appendChild(row);
            });
        };
    }

    function BidsTable(_bidsContainer, _bidsContainerBody, id) {
        this.bidsContainer = _bidsContainer;
        this.bidsContainerBody = _bidsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "GetBids?auctionId=" + id, null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let bidsTableToShow = JSON.parse(req.responseText);
                            if (bidsTableToShow.length === 0) {
                                bidsAlert.textContent = "There are no bids for this auction, be the first!";
                            }
                            self.update(bidsTableToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(eq.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(bidsTableToShow) {
            let row;
            let usernameCell;
            let dateTimeCell;
            let amountCell;

            this.bidsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly



            bidsTableToShow.forEach(function(bid) { // self visible in nested function by closure



                row = document.createElement("tr");

                dateTimeCell = document.createElement("td");
                dateTimeCell.textContent = bid.date_time;
                row.appendChild(dateTimeCell);

                usernameCell = document.createElement("td");
                usernameCell.textContent = bid.username;
                row.appendChild(usernameCell);

                amountCell = document.createElement("td");
                amountCell.textContent = bid.amount;
                row.appendChild(amountCell);

                self.bidsContainerBody.appendChild(row);
            });
        };
    }

    function SearchingForm(searchingForm) {
        this.searchingForm = searchingForm;
        this.buyingAuctionsTable = document.getElementById("buyingAucitonsTable");
        this.registerClick = function() {

            // Obtain button and set click listener
            this.searchingForm.querySelector("input[type='button']").addEventListener('click',
                (e) => {
                    // Obtain form form event
                    var form = e.target.closest("form");

                    // Check form validity -- other validation could be added here if needed --
                    // https://developer.mozilla.org/es/docs/Web/API/HTMLSelectElement/checkValidity
                    if (form.checkValidity()) {
                        var self = this;
                        // if form is valid, then make post request
                        makeCall("POST", "Search", form,
                            function(req) {
                                if (req.readyState == XMLHttpRequest.DONE) {
                                    var message = req.responseText;
                                    if (req.status == 200) {
                                        let x = JSON.parse(req.responseText);
                                        buyingAuctionsTable.update(x);
                                    } else {
                                        // show message from server or a custom one
                                        if (message == "")
                                            message = "An issue has occurred";
                                        alert(message); //alert for demo purposes, could be displayed on the HTML
                                    }
                                }
                            }
                        );
                    } else {
                        // if not valid, report it to user -- custom error messages could be added here -- 
                        // https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/reportValidity
                        form.reportValidity();
                    }
                });
        }
    }

    function BiddingForm(biddingForm, id) {
        this.biddingForm = biddingForm;
        this.bidList = bidList;
        this.registerClick = function() {

            // Obtain button and set click listener
            this.biddingForm.querySelector("input[type='button']").addEventListener('click',
                (e) => {
                    // Obtain form form event
                    var form = e.target.closest("form");

                    // Check form validity -- other validation could be added here if needed --
                    // https://developer.mozilla.org/es/docs/Web/API/HTMLSelectElement/checkValidity
                    if (form.checkValidity()) {
                        var self = this;
                        // if form is valid, then make post request
                        makeCall("POST", "CreateBid?auctionId=" + id, form,
                            function(req) {
                                if (req.readyState == XMLHttpRequest.DONE) {
                                    var message = req.responseText;
                                    if (req.status == 200) {
                                        buyingAuctionsTable.show();
                                        winningAuctionsBulletList.show();
                                        biddingPage.classList.remove("displayed");
                                        biddingPage.classList.add("masked");
                                    } else {
                                        // show message from server or a custom one
                                        if (message == "")
                                            message = "An issue has occurred";
                                        alert(message); //alert for demo purposes, could be displayed on the HTML
                                    }
                                }
                            }
                        );
                    } else {
                        // if not valid, report it to user -- custom error messages could be added here -- 
                        // https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/reportValidity
                        form.reportValidity();
                    }
                });
        }
    }

    function ItemForm(itemForm) {
        this.itemForm = itemForm;
        this.registerClick = function() {

            // Obtain button and set click listener
            this.itemForm.querySelector("input[type='button']").addEventListener('click',
                (e) => {
                    // Obtain form form event
                    var form = e.target.closest("form");

                    // Check form validity -- other validation could be added here if needed --
                    // https://developer.mozilla.org/es/docs/Web/API/HTMLSelectElement/checkValidity
                    if (form.checkValidity()) {
                        var self = this;
                        // if form is valid, then make post request
                        makeCall("POST", "CreateItem", form,
                            function(req) {
                                if (req.readyState == XMLHttpRequest.DONE) {
                                    var message = req.responseText;
                                    if (req.status == 200) {
                                        yourItemsTable.show();

                                    } else {
                                        // show message from server or a custom one
                                        if (message == "")
                                            message = "An issue has occurred";
                                        alert(message); //alert for demo purposes, could be displayed on the HTML
                                    }
                                }
                            }
                        );
                    } else {
                        // if not valid, report it to user -- custom error messages could be added here -- 
                        // https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/reportValidity
                        form.reportValidity();
                    }
                });
        }
    }

    function AuctionForm(auctionForm) {
        this.auctionForm = auctionForm;
        this.registerClick = function() {

            // Obtain button and set click listener
            this.auctionForm.querySelector("input[type='button']").addEventListener('click',
                (e) => {
                    // Obtain form form event
                    var form = e.target.closest("form");

                    // Check form validity -- other validation could be added here if needed --
                    // https://developer.mozilla.org/es/docs/Web/API/HTMLSelectElement/checkValidity
                    if (form.checkValidity()) {
                        var self = this;
                        var elements = [];
                        var x = document.querySelector("#selectedItemsTable").querySelectorAll("#selectedItems");
                        for (let i = 0; i < x.length; i++) {
                            elements[i] = x[i].textContent;
                        }

                        // if form is valid, then make post request
                        makeCallList("POST", "CreateAuction", form, elements,
                            function(req) {
                                if (req.readyState == XMLHttpRequest.DONE) {
                                    var message = req.responseText;
                                    if (req.status == 200) {
                                        yourItemsTable.show();
                                        selectedItemsFlush();
                                        sellingAuctionsTable.show();

                                    } else {
                                        // show message from server or a custom one
                                        if (message == "")
                                            message = "An issue has occurred";
                                        alert(message); //alert for demo purposes, could be displayed on the HTML
                                    }
                                }
                            }
                        );
                        var create = {
                            value: 1,
                            scadenza: new Date().getTime() + 30 * 24 * 60 * 60 * 1000
                        };
                        localStorage.setItem("create", JSON.stringify(create));
                    } else {
                        // if not valid, report it to user -- custom error messages could be added here -- 
                        // https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/reportValidity
                        form.reportValidity();
                    }
                });
        }
    }

    function ShowAllButton(showAllButton) {
        this.showALlButton = showAllButton
        this.registerClick = function() {

            // Obtain button and set click listener
            document.getElementById("showAllButton").addEventListener('click',
                (e) => {

                    // if form is valid, then make post request
                    makeCall("GET", "LoadBuyingAuctions", null,
                        function(req) {
                            if (req.readyState == XMLHttpRequest.DONE) {
                                var message = req.responseText;
                                if (req.status == 200) {
                                    buyingAuctionsTable.showAll();

                                } else {
                                    // show message from server or a custom one
                                    if (message == "")
                                        message = "An issue has occurred";
                                    alert(message); //alert for demo purposes, could be displayed on the HTML
                                }
                            }
                        }
                    );
                }
            );
        }
    }

    function YourItemsTable(_yourItemsContainer, _yourItemsContainerBody) {
        this.yourItemsContainer = _yourItemsContainer;
        this.yourItemsContainerBody = _yourItemsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "LoadYourItems", null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let yourItemsToShow = JSON.parse(req.responseText);
                            if (yourItemsToShow.length === 0) {
                                yourItemsAlert.textContent = "No auctions yet!";
                                return;
                            }
                            self.update(yourItemsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(yourItemsToShow) {
            let row;
            let idCodeCell;
            let nameCell;
            let descriptionCell;
            let imageCell;
            let priceCell;
            let img;

            this.yourItemsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly

            emptyRow = document.createElement("tr");
            emptyRow.id = "anchorRow"
            emptyRow.className = "draggable";
            let y = emptyRow
            y.draggable = true;
            y.addEventListener("dragstart", dragStart); //save dragged element reference
            y.addEventListener("dragover", dragOver); // change color of reference element to red
            y.addEventListener("dragleave", dragLeave); // change color of reference element to black
            y.addEventListener("drop", drop);

            emptyIdCodeCell = document.createElement("td");
            emptyRow.appendChild(emptyIdCodeCell);
            emptyNameCell = document.createElement("td");
            emptyRow.appendChild(emptyNameCell);
            emptyDescriptionCell = document.createElement("td");
            emptyRow.appendChild(emptyDescriptionCell);
            emptyImageCell = document.createElement("td");
            emptyRow.appendChild(emptyImageCell);
            emptyPriceCell = document.createElement("td");
            emptyRow.appendChild(emptyPriceCell);
            this.yourItemsContainerBody.appendChild(emptyRow);

            yourItemsToShow.forEach(function(item) { // self visible in nested function by closure

                row = document.createElement("tr");
                row.className = "draggable";

                row.draggable = true;
                row.addEventListener("dragstart", dragStart); //save dragged element reference
                row.addEventListener("dragover", dragOver); // change color of reference element to red
                row.addEventListener("dragleave", dragLeave); // change color of reference element to black
                row.addEventListener("drop", drop); //change position of dragged element using the referenced element 


                idCodeCell = document.createElement("td");
                idCodeCell.id = "selectedItems";

                idCodeCell.textContent = item.id_code;
                //anchor.setAttribute("topicid", topic.id);
                row.appendChild(idCodeCell);

                //idCodeCell.addEventListener("click", getBiddingPage, false);

                nameCell = document.createElement("td");
                nameCell.textContent = item.name;
                row.appendChild(nameCell);

                descriptionCell = document.createElement("td");
                descriptionCell.textContent = item.description;
                row.appendChild(descriptionCell);



                imageCell = document.createElement("td");
                /*img = document.createElement("img");
                img.src = imageUrl;
                imageCell.appendChild(img);*/
                row.appendChild(imageCell);

                priceCell = document.createElement("td");
                priceCell.textContent = item.price;
                row.appendChild(priceCell);


                self.yourItemsContainerBody.appendChild(row);
            });
        };
    }

    function SellingAuctionsTable(_sellingAuctionsContainer, _sellingAuctionsContainerBody) {
        this.sellingAuctionsContainer = _sellingAuctionsContainer;
        this.sellingAuctionsContainerBody = _sellingAuctionsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "LoadSellingAuctions", null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let sellingAuctionsToShow = JSON.parse(req.responseText);
                            if (sellingAuctionsToShow.length === 0) {
                                sellingAuctionsAlert.textContent = "No auctions yet!";
                                return;
                            }
                            self.update(sellingAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(sellingAuctionsToShow) {
            let row;
            let idCodeCell;
            let timeLeftCell;
            let currentPriceCell;
            this.sellingAuctionsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly
            sellingAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure

                row = document.createElement("tr");

                let idCodeCell = document.createElement("td");
                idCodeCell.textContent = auction.id_code;
                //anchor.setAttribute("topicid", topic.id);
                row.appendChild(idCodeCell);

                idCodeCell.addEventListener("click", function() {
                    auctionDetailsTable = new AuctionDetailsTable(
                        document.getElementById("auctionDetailsTable"),
                        document.getElementById("auctionDetailsTableBody"),
                        idCodeCell.textContent
                    )
                    auctionDetailsPage.className = "displpayed";
                    auctionDetailsTable.show();
                    itemsBiddingList = new ItemsTable(
                        document.getElementById("itemListTable"),
                        document.getElementById("itemListTableBody"),
                        idCodeCell.textContent
                    );
                    itemsBiddingList.show();
                    bidList = new BidsTable(
                        document.getElementById("offersTable"),
                        document.getElementById("offersTableBody"),
                        idCodeCell.textContent
                    );
                    bidList.show();
                }, false);

                timeLeftCell = document.createElement("td");
                timeLeftCell.textContent = auction.time_left;
                row.appendChild(timeLeftCell);

                currentPriceCell = document.createElement("td");
                currentPriceCell.textContent = auction.current_price;
                row.appendChild(currentPriceCell);

                self.sellingAuctionsContainerBody.appendChild(row);
            });
        };
    }

    function ExpiredAuctionsTable(_expiredAuctionsContainer, _expiredAuctionsContainerBody) {
        this.expiredAuctionsContainer = _expiredAuctionsContainer;
        this.expiredAuctionsContainerBody = _expiredAuctionsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "LoadExpiredAuctions", null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let expiredAuctionsToShow = JSON.parse(req.responseText);
                            if (expiredAuctionsToShow.length === 0) {
                                expiredAuctionsAlert.textContent = "No auctions yet!";
                                return;
                            }
                            self.update(expiredAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(expiredAuctionsToShow) {
            let row;
            let idCodeCell;
            let currentPriceCell;
            this.expiredAuctionsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly
            expiredAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure

                row = document.createElement("tr");

                let idCodeCell = document.createElement("td");
                idCodeCell.textContent = auction.id_code;
                //anchor.setAttribute("topicid", topic.id);
                row.appendChild(idCodeCell);

                currentPriceCell = document.createElement("td");
                currentPriceCell.textContent = auction.current_price;
                row.appendChild(currentPriceCell);

                let closeCell = document.createElement("td");
                closeCell.textContent = "Close";
                row.appendChild(closeCell);

                closeCell.addEventListener("click", function() {
                    makeCall("GET", "CloseAuction?auctionId=" + idCodeCell.textContent, null,
                        function(req) { // callback of the GET request
                            if (req.readyState === 4) {
								var message = req.responseText;
                                if (req.status === 200) {
                                    expiredAuctionsTable.show();
                                    closedAuctionsTable.show(); // self visible by closure, view status has topic ID as parameter
                                } else { //printing errors
                                    alert(message);
                                }
                            }
                        }
                    );
                }, false);


                idCodeCell.addEventListener("click", function() {
                    auctionDetailsTable = new AuctionDetailsTable(
                        document.getElementById("auctionDetailsTable"),
                        document.getElementById("auctionDetailsTableBody"),
                        idCodeCell.textContent
                    )
                    auctionDetailsPage.className = "displpayed";
                    auctionDetailsTable.show();
                    itemsBiddingList = new ItemsTable(
                        document.getElementById("itemListTable"),
                        document.getElementById("itemListTableBody"),
                        idCodeCell.textContent
                    );
                    itemsBiddingList.show();
                    bidList = new BidsTable(
                        document.getElementById("offersTable"),
                        document.getElementById("offersTableBody"),
                        idCodeCell.textContent
                    );
                    bidList.show();
                }, false);


                self.expiredAuctionsContainerBody.appendChild(row);
            });
        };
    }

    function ClosedAuctionsTable(_closedAuctionsContainer, _closedAuctionsContainerBody) {
        this.closedAuctionsContainer = _closedAuctionsContainer;
        this.closedAuctionsContainerBody = _closedAuctionsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "LoadClosedAuctions", null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let closedAuctionsToShow = JSON.parse(req.responseText);
                            if (closedAuctionsToShow.length === 0) {
                                closedAuctionsAlert.textContent = "No auctions yet!";
                                return;
                            }
                            self.update(closedAuctionsToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(closedAuctionsToShow) {
            let row;
            let idCodeCell;
            let currentPriceCell;
            let winnerNameCell;
            let winnerAddressCell;

            this.closedAuctionsContainerBody.innerHTML = ""; // empty the table body
            // build updated list
            let self = this; //  nested function updates the object bound to this, which is not visible directly
            closedAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure

                row = document.createElement("tr");

                let idCodeCell = document.createElement("td");
                idCodeCell.textContent = auction.id_code;
                //anchor.setAttribute("topicid", topic.id);
                row.appendChild(idCodeCell);

                idCodeCell.addEventListener("click", function() {
                    auctionDetailsTable = new AuctionDetailsTable(
                        document.getElementById("auctionDetailsTable"),
                        document.getElementById("auctionDetailsTableBody"),
                        idCodeCell.textContent
                    )
                    auctionDetailsPage.className = "displpayed";
                    auctionDetailsTable.show();
                    itemsBiddingList = new ItemsTable(
                        document.getElementById("itemListTable"),
                        document.getElementById("itemListTableBody"),
                        idCodeCell.textContent
                    );
                    itemsBiddingList.show();
                    bidList = new BidsTable(
                        document.getElementById("offersTable"),
                        document.getElementById("offersTableBody"),
                        idCodeCell.textContent
                    );
                    bidList.show();
                }, false);

                //idCodeCell.addEventListener("click", getBiddingPage, false);

                currentPriceCell = document.createElement("td");
                currentPriceCell.textContent = auction.current_price;
                row.appendChild(currentPriceCell);

                winnerNameCell = document.createElement("td");
                winnerNameCell.textContent = auction.winner_name;
                row.appendChild(winnerNameCell);

                winnerAddressCell = document.createElement("td");
                winnerAddressCell.textContent = auction.winner_address;
                row.appendChild(winnerAddressCell);

                self.closedAuctionsContainerBody.appendChild(row);
            });
        };
    }

    function AuctionDetailsTable(_auctionDetailsContainer, _auctionDetailsContainerBody, auctionId) {
        this.auctionDetailsContainer = _auctionDetailsContainer;
        this.auctionDetailsContainerBody = _auctionDetailsContainerBody;

        this.show = function() {
            let self = this; // this not direcly visible in nested functions,
            // need to copy it in a local variable
            makeCall("GET", "LoadAuctionDetails?auctionId=" + auctionId, null,
                function(req) { // callback of the GET request
                    if (req.readyState === 4) {
                        if (req.status === 200) {
                            let auctionToShow = JSON.parse(req.responseText);
                            if (auctionToShow == null) {
                                auctionDetailsAlert.textContent = "something wrong, auction is null";
                                return;
                            }
                            self.update(auctionToShow); // self visible by closure, view status has topic ID as parameter
                        } else { //printing errors
                            alert(req.responseText);
                        }
                    }
                }
            );
        };

        this.update = function(auctionToShow) {
            let row;
            let idCodeCell;
            let expiryDateTimeCell;
            let minimumOffsetCell;
            let totalValueCell;
            let highestOfferCell;

            this.auctionDetailsContainerBody.innerHTML = ""; // empty the table body
            // build updated list

            row = document.createElement("tr");

            idCodeCell = document.createElement("td");
            idCodeCell.textContent = auctionToShow.id_code;
            row.appendChild(idCodeCell);

            expiryDateTimeCell = document.createElement("td");
            expiryDateTimeCell.textContent = auctionToShow.expiry_date_time;
            row.appendChild(expiryDateTimeCell);

            minimumOffsetCell = document.createElement("td");
            minimumOffsetCell.textContent = auctionToShow.minimum_offset;
            row.appendChild(minimumOffsetCell);

            totalValueCell = document.createElement("td");
            totalValueCell.textContent = auctionToShow.total_value;
            row.appendChild(totalValueCell);

            highestOfferCell = document.createElement("td");
            highestOfferCell.textContent = auctionToShow.highest_offer;
            row.appendChild(highestOfferCell);

            this.auctionDetailsContainerBody.appendChild(row);
        };
    }

    // Drag and Drop

    /* 
          This fuction puts all row to "notselected" class, 
          then we use CSS to put "notselected" in black and "selected" in red
      */
    function unselectRows(rowsArray) {
        for (var i = 0; i < rowsArray.length; i++) {
            rowsArray[i].classList.add("notselected");
        }
    }


    /* 
        The dragstart event is fired when the user starts 
        dragging an element (if it is draggable=True)
        https://developer.mozilla.org/en-US/docs/Web/API/Document/dragstart_event
    */
    function dragStart(event) {
        /* we need to save in a variable the row that provoked the event
         to then move it to the new position */
        startElement = event.target.closest("tr");
        console.log(startElement);
    }

    /*
        The dragover event is fired when an element 
        is being dragged over a valid drop target.
        https://developer.mozilla.org/es/docs/Web/API/Document/dragover_event
    */
    function dragOver(event) {
        // We need to use prevent default, otherwise the drop event is not called
        event.preventDefault();

        // We need to select the row that triggered this event to marked as "selected" so it's clear for the user
        var dest = event.target.closest("tr");

        // Mark  the current element as "selected", then with CSS we will put it in red
        dest.className = "selected";
    }

    /*
        The dragleave event is fired when a dragged 
        element leaves a valid drop target.
        https://developer.mozilla.org/en-US/docs/Web/API/Document/dragleave_event
    */
    function dragLeave(event) {
        // We need to select the row that triggered this event to marked as "notselected" so it's clear for the user 
        var dest = event.target.closest("tr");

        // Mark  the current element as "notselected", then with CSS we will put it in black
        dest.className = "notselected";
    }

    /*
        The drop event is fired when an element or text selection is dropped on a valid drop target.
        https://developer.mozilla.org/en-US/docs/Web/API/Document/drop_event
    */
    function drop(event) {

        var dest = event.target.closest("tr");
        var tableDestination = event.target.closest("table");
        // Obtain the index of the row in the table to use it as reference
        // for changing the dragged element position
        var table = dest.closest('table');
        var rowsArray = Array.from(table.querySelectorAll('tbody > tr'));
        var rowsArray2 = Array.from(tableDestination.querySelectorAll('tbody > tr'));
        var indexDest = rowsArray.indexOf(dest);

        if (startElement.closest("table") !== tableDestination) {
            var tableBody = tableDestination.querySelector("tbody");
            tableBody.appendChild(startElement);

        }

        // Move the dragged element to the new position
        if (rowsArray.indexOf(startElement) < indexDest)
            // If we're moving down, then we insert the element after our reference (indexDest)
            startElement.parentElement.insertBefore(startElement, rowsArray[indexDest + 1]);
        else
            // If we're moving up, then we insert the element before our reference (indexDest)
            startElement.parentElement.insertBefore(startElement, rowsArray[indexDest]);

        // Mark all rows in "not selected" class to reset previous dragOver
        unselectRows(rowsArray);
        unselectRows(rowsArray2);

    }
} //closing visibility block