package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.BidDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.User;

import it.polimi.tiw.projects.connection.ConnectionHandler;

@WebServlet("/LoadStorageBuyingAuctions")
@MultipartConfig
public class LoadStorageBuyingAuctions extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
     
    public LoadStorageBuyingAuctions() {
        super();
    }
    
    
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AuctionDAO auctionDAO = new AuctionDAO(connection);
		List<Auction> auctions = new ArrayList<Auction>();
		HttpSession s = request.getSession(false);
		User user = (User) s.getAttribute ("user");
		LocalDateTime loginTime = (LocalDateTime)s.getAttribute("time");
		
		String list = request.getParameter("list");
		
		List<Integer> integerList = Arrays.stream(list.split(","))
                .map(String::trim)
                .map(Integer::parseInt)
                .collect(Collectors.toList());
		
		
		//questo controllo verrà fatto con i filtri
		if (user == null) {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); //401
			response.getWriter().write("DB error");
			return;
		}
		
		try {
			auctions = auctionDAO.storageAuctions(user, loginTime, integerList);
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); //500
			response.getWriter().write("DB error");
			return;
		}
		
		Gson json = new Gson();
		String jsonString = json.toJson(auctions);
		response.setStatus(HttpServletResponse.SC_OK); //200
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonString);
	}
	
	public void destroy () {
		try {
			ConnectionHandler.closeConnection(connection);
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
