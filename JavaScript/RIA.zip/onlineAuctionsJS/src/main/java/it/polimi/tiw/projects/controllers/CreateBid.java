package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.BidDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class Search
 */
@WebServlet("/CreateBid")
@MultipartConfig
public class CreateBid extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateBid() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute("user");
		BidDAO bidDAO = new BidDAO(connection);
		AuctionDAO auctionDAO = new AuctionDAO(connection);
		int auctionId = 0;
		float amount = 0;
		boolean flag = false;
		float highestBid = 0;
		float minimumOffset = 0;
		String errorMsg = "";
		Auction auction;
		
		//controllo che ci siano entrambi i parametri
		try {
			auctionId = Integer.parseInt(request.getParameter("auctionId"));
			amount = Float.parseFloat(request.getParameter("bidAmount"));
			System.out.println(amount);
		}catch (Exception e) {
			errorMsg = "invalid parameters";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().print(errorMsg);
			return;
		}
		
		//controlla che auctionId esista nella lista delle aste aperte prima di creare un'offerta per quello
		try {
			flag = auctionDAO.containsInOpenAuctions(auctionId);
	
		} catch (SQLException SQLe) {
			SQLe.printStackTrace ();
			errorMsg = "Error in the DB";
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().print(errorMsg);
			return;
		}
		
		//controllo che amount sia un valore valido
		try {
			highestBid = bidDAO.getHighestBid(auctionId);
		} catch (SQLException e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			errorMsg = "Error in the DB";
			response.getWriter().print(errorMsg);
			return;
		}
		auction = auctionDAO.getAuctionDetails(auctionId);
		if (highestBid == 0) {
			highestBid = auction.getCurrent_Price();
		}
		minimumOffset = auction.getMinimum_Offset();
		
		//controllo che l'username di chi fa l'offerta debba essere diverso da quello di chi ha creato l'asta? 
				
		try {
			if (flag && highestBid + minimumOffset < amount) {
				bidDAO.createBid (user.getUsername(), auctionId, amount);
			}
			else if (!flag) {
				errorMsg = "invalid auction id";
			}
			else {
				errorMsg = "invalid amount";
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage() + "Error in the DB");
			return;
		}
		
		response.setStatus(HttpServletResponse.SC_OK); //200
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
