package it.polimi.tiw.projects.utils;

public class MissingTime {
    private int days;
    private long hours;
    private long minutes;
    private long seconds;

    public MissingTime(int days, long hours, long minutes, long seconds) {
        this.days = days;
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public long getHours() {
        return hours;
    }

    public void setHours(long hours) {
        this.hours = hours;
    }

    public long getMinutes() {
        return minutes;
    }

    public void setMinutes(long minutes) {
        this.minutes = minutes;
    }

    public long getSeconds() {
        return seconds;
    }

    public void setSeconds(long seconds) {
        this.seconds = seconds;
    }
    
    public String toString() {
    	return "\nDays: " + days + 
    			"\nHours: " + hours + 
    			"\nMinutes: " + minutes +
    			"\nSeconds: " + seconds;
    }
}

