package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.beans.Item;
import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.exceptions.ParameterException;

/**
 * Servlet implementation class GetBidItems
 */
@WebServlet("/GetBidItems")
@MultipartConfig
public class GetBidItems extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetBidItems() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ItemDAO itemDAO = new ItemDAO (connection);
		List <Item> items;
		int auctionId = 0;
		
		//check query string parameters
		try {
			String id = request.getParameter("auctionId");
			if(id == null) {
				throw new ParameterException();
			}
			auctionId = Integer.parseInt(id);
			
		} catch (ParameterException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Wrong parameter");
			return;
		}
		
		//find items
		try {
			items = itemDAO.findItems(auctionId);
		} catch (SQLException e) {
			String errorMessage = "DB ERROR";
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write(errorMessage);
			return;
		}
		
		Gson json = new Gson();
		String jsonString = json.toJson(items);
		response.setStatus(HttpServletResponse.SC_OK); //200
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonString);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
