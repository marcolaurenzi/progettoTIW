package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;

import com.google.gson.Gson;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class Search
 */
@WebServlet("/Search")
@MultipartConfig
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// As usual, obtain and validate parameters
		String keyWord = request.getParameter("keyWord");
		List <Auction> auctions = new ArrayList<Auction>();
		HttpSession s = request.getSession();
		User user = (User) s.getAttribute("user");
		LocalDateTime loginTime = (LocalDateTime)s.getAttribute("time");
		
		if (keyWord == null) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400
			response.getWriter().println("Parameters incomplete");
			return;
		}
		
		// todo controllare che cerchi solo aste non tue
		
		AuctionDAO auctionDAO = new AuctionDAO (connection);
		
		//openAuctionsContainingKeyWord
		try {
			auctions = auctionDAO.descendingOrderOpenAuctionsContainingKeyWord(keyWord, user, loginTime);
		} catch (SQLException e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500
			response.getWriter().println("Not possible to recover auctions");
			return;
		}
		
		Gson json = new Gson();
		String jsonString = json.toJson(auctions);
		response.setStatus(HttpServletResponse.SC_OK); //200
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonString);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
