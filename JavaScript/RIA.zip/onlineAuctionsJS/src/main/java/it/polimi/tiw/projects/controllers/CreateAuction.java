package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.exceptions.DateTimeException;
import it.polimi.tiw.projects.exceptions.ParameterException;
import it.polimi.tiw.projects.exceptions.UserException;

/**
 * Servlet implementation class CreateAuction
 */
@WebServlet("/CreateAuction")
@MultipartConfig
public class CreateAuction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;   
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAuction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String errorMessage = null;
		String list = request.getParameter("list");
		
		if(list == null || list.isEmpty()) {
			errorMessage = "incomplete informations";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().print(errorMessage);
			return;
		}
		
		List<Integer> integerList = Arrays.stream(list.split(","))
                .map(String::trim)
                .map(Integer::parseInt)
                .collect(Collectors.toList());
		int id_code = 0;
		User user = null;
		LocalDateTime expiry_date_time = null;
		float minimum_offset;
		AuctionDAO auctionDao = new AuctionDAO(connection);
		String datetimeString = null;
		String rise = null;
		
		try {
			
			// lettura data e ora
			datetimeString = request.getParameter("date");
			// lettura offset
			rise = request.getParameter("offset");
			if(datetimeString == null || rise == null) {
				throw new ParameterException();
			}
			// lettura username
			user = (User) request.getSession().getAttribute("user");
			if(user == null) {
				throw new UserException();
			}
			// conversione
			expiry_date_time = LocalDateTime.parse(datetimeString, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			// conversione
			minimum_offset = Float.parseFloat(rise);
			if (list.length() == 0 || minimum_offset <= 0) {
				throw new ParameterException();
			}
			if(expiry_date_time.isBefore(LocalDateTime.now())) {
				throw new DateTimeException();
			}
		
		} catch (UserException e) {
			errorMessage = "invalid user";
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.getWriter().print(errorMessage);
			return;
		} catch(ParameterException e) {
			errorMessage = "incomplete informations";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().print(errorMessage);
			return;
		} catch(DateTimeException e) {
			errorMessage = "incorrect expiry date and time";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().print(errorMessage);
			return;
		}

		//insert the new auction in the DB
		try {
			id_code = auctionDao.getNextIdCode();
			auctionDao.createAuction(id_code + 1, user.getUsername(), expiry_date_time, minimum_offset);
			for(Integer i : integerList) {
				auctionDao.addItem(id_code+1, i);
			}
			auctionDao.openAuction(id_code+1);
		} catch (SQLException e) {
			errorMessage = "DB Error, try again";
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().print(errorMessage);
			return;
		}
		response.setStatus(HttpServletResponse.SC_OK);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
