package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.exceptions.AuctionException;
import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.beans.User;

/**
 * Servlet implementation class CloseAuction
 */
@WebServlet("/CloseAuction")
public class CloseAuction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CloseAuction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer id_code = null;
		AuctionDAO auctionDao = new AuctionDAO(connection);
		String errorMessage;
		HttpSession s = request.getSession(false);
		User user = (User) s.getAttribute ("user");
		
		if (user == null) {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); //401
			response.getWriter().write("unauthorized");
			return;
		}
		
		try {
			String toParse = request.getParameter("auctionId");
			id_code = Integer.parseInt(toParse);
		}
		catch (Exception e){
			errorMessage = "parameters incomplete or wrong";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().write(errorMessage);
			return;
		}
		
		try {
			if(!auctionDao.findAllExpiredAuctionsId(user).contains(id_code)) {
				throw new AuctionException();
			}
			
		}catch (AuctionException e) {
			errorMessage = "parameters incomplete or wrong";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().write(errorMessage);
			return;
		} catch (SQLException e) {
			errorMessage = "error in the db";
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write(errorMessage);
			return;
		}
		
		
		auctionDao.closeAuction(id_code);
		response.setStatus(HttpServletResponse.SC_OK);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
