package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.BidDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.exceptions.AuctionException;
import it.polimi.tiw.projects.exceptions.ParameterException;

/**
 * Servlet implementation class LoadAuctionDetails
 */
@WebServlet("/LoadAuctionDetails")
@MultipartConfig
public class LoadAuctionDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}   
    
    public LoadAuctionDetails() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AuctionDAO auctionDAO = new AuctionDAO(connection);
		BidDAO bidDAO = new BidDAO(connection);
		Auction auction = null;
		String auctionIdString = null;
		int auctionId = -1;
		
		try {
			auctionIdString = request.getParameter("auctionId");
			if (auctionIdString == null || auctionIdString.isBlank()) { 
				throw new ParameterException();
			}
			auctionId = Integer.parseInt(auctionIdString);
			if (auctionId < 0) {
				throw new ParameterException();
			}
		}catch (ParameterException e) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST); //400
			response.getWriter().write("auctionId is not present or is invalid");
			return;
		}
		
		try {
			//gets id, minimumOffset and expiration
			auction = auctionDAO.getAuctionDetails(auctionId);
			
			if (auction == null) {
				throw new AuctionException();
			}
			auction.setHighest_Offer(bidDAO.getHighestBid(auctionId));
			auction.setTotal_Value(auctionDAO.getTotalValue(auctionId));
		} catch(SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); //500
			response.getWriter().write("auctionId is not present or is invalid");
			return;
		} catch (AuctionException e) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST); //400
			response.getWriter().write("auctionId doesn't exist");
			return;
		}
	
		Gson json = new Gson();
		String jsonString = json.toJson(auction);
		response.setStatus(HttpServletResponse.SC_OK); //200
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonString);
	}
	
	public void destroy () {
		try {
			ConnectionHandler.closeConnection(connection);
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
