package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.BidDAO;
import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.AuctionJS;
import it.polimi.tiw.projects.beans.Item;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class LoadWinningAuctions
 */
@WebServlet("/LoadWinningAuctionsTable")
@MultipartConfig
public class LoadWinningAuctionsTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection;
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadWinningAuctionsTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s = request.getSession();
		User user = (User) s.getAttribute("user");
		AuctionDAO auctionDAO = new AuctionDAO (connection);
		BidDAO bidDao = new BidDAO(connection);
		List <Auction> winningAuctions= new ArrayList <Auction> ();
		List <AuctionJS> winningAuctionsJS = new ArrayList <AuctionJS> ();
		//Map <Auction, List<Item>> wonAuctionsMap= new HashMap <Auction, List<Item>> ();
		
		
		//find the list of auction won by the username taken from the session
		try {
			winningAuctions = auctionDAO.auctionWinningBy(user.getUsername());
			//wonAuctions = auctionDAO.auctionWonBy(user.getUsername());
		}catch (SQLException SQLe) {
			SQLe.printStackTrace();
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "DB error: won auction search failed");
			return;
		}
		
		for (Auction a : winningAuctions) {
			AuctionJS auctionJS = new AuctionJS();
			auctionJS.setId_Code(a.getId_Code());
			auctionJS.setMinimum_Offset(a.getMinimum_Offset());
			winningAuctionsJS.add(auctionJS);
	
			float curr;
			try {
				curr = bidDao.getHighestBid(a.getId_Code());
			} catch (SQLException e) {
				e.printStackTrace();
				return;
			}
			auctionJS.setCurrent_Bid(curr);
			
		}
		
		Gson json = new Gson();
		String jsonString = json.toJson(winningAuctionsJS);
		response.setStatus(HttpServletResponse.SC_OK); //200
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonString);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
