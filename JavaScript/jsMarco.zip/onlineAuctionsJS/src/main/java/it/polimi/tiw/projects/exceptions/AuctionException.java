package it.polimi.tiw.projects.exceptions;

public class AuctionException extends Throwable{

	private static final long serialVersionUID = 1L;

}
