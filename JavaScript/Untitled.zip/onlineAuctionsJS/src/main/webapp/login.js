window.onload = function() {
	document.getElementById ("loginForm").addEventListener("submit", login, false);
	
}

//called when form submits
function login (e) {
      let form = e.target.closest("form");
      if (form.checkValidity()) {
        let topicOfMessage = form.querySelector("input[type = 'hidden']").value;
        e.preventDefault();
        makeCall("POST", "Login", form,
          function(req) { // callback
            if (req.readyState === 4) { // response has arrived
              if (req.status === 200) { // if no errors
                alertContainer.textContent = "Message created for topic with ID" + topicOfMessage;
                messageList.show(topicOfMessage); // update the view to show the new message
              } 
              else if (req.status === 400) {
				let message = "invalid parameters"
				//creare il node per il messaggio e appenderlo all'HTML
              }
              else { //req.status === 500
				let message = "internal server error"
				//creare il node per il messaggio e appenderlo all'HTML
			  }
            }
          }
        );
      }
      else {
        form.reportValidity(); // trigger the client-side HTML error messaging
      }
}