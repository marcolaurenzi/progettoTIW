{//defining scope of the variables with this visibility block
	
let buyingAuctionsTable = null;
let buyingAuctionsAlert = document.getElementById ("buyingAuctionsAlert");
let winningAuctionsBulletList = null;
//let winningAuctionsTable = null;
let winningAuctionsAlert = document.getElementById ("winningAuctionsAlert");
//let wonAuctionsTable = null;
//let wonAuctionsAlert = document.getElementById ("wonAuctionsAlert");



window.onload = function() {
	winningAuctionsBulletList = new WinningAuctionsBulletList(
	document.getElementById ("winningAuctionsBulletList"));
	
	buyingAuctionsTable = new BuyingAuctionsTable(
    document.getElementById("buyingAuctionsTable"),
    document.getElementById("buyingAuctionsTableBody"));
    
    /*
    winningAuctionsTable = new WinningAuctionsTable(
    document.getElementById("winningAuctionsTable"),
    document.getElementById("winningAuctionsTableBody"));
    
    wonAuctionsTable = new WonAuctionsTable(
    document.getElementById("wonAuctionsTable"),
    document.getElementById("wonAuctionsTableBody"));
    */

	winningAuctionsBulletList.show();
  	buyingAuctionsTable.show();
  	//winningAuctionsTable.show();
  	//wonAuctionsTable.show();
}

function WinningAuctionsBulletList (_winningAuctionsBulletList) {
	this.winningAuctionsBulletList = _winningAuctionsBulletList;
	
	this.show = function () {
		let self = this;
		makeCall ("GET", "LoadWinningAuctions", null,
		function(req) { //callback of the get request
			if (req.readyState === 4) {
            if (req.status === 200) {
              let winningAuctionsToShow = JSON.parse(req.responseText);
              if (winningAuctionsToShow.length === 0) {
                winningAuctionsAlert.textContent = "No winning auctions yet!";
                return;
              }
              self.update(winningAuctionsToShow); // self visible by closure, view status has topic ID as parameter
            } else { //printing errors
              winningAuctionsAlert.textContent = req.responseText;
            }
          }
		});
	}
		
	this.update = function(winningAuctionsToShow) {
		let bulletPoint;
		let infoRow;
		let table;
		let thead;
		let tbody;
		let row;
		let bodyRow
		let idHeader;
		let nameHeader;
		let descriptionHeader;
		let usernameHeader;
		let imageHeader;
		let priceHeader;
      	let idCell;
      	let nameCell;
      	let descriptionCell;
      	let usernameCell;
      	let imageCell;
      	let priceCell;
		
      
      	this.winningAuctionBulletList.innerHTML = ""; // empty the bullet list
      	// build updated list
     	let self = this; //  nested function updates the object bound to this, which is not visible directly
      	winningAuctionsToShow.forEach(function(entry) { // self visible in nested function by closure
        
        bulletPoint = document.createElement("li");
        infoRow = document.createElement("p");
        infoRow.textContent = "auction code: " + entry.key.id_code;
        //+ "seller username:  " + entry.key.username + "current price: " + entry.key.current_price;
        bulletPoint.append(infoRow);
        //building the table
        table = document.createElement("table");
        //filling table head
        thead = document.createElement("thead");
        
        row = document.createElement("tr");
        idHeader = document.createElement("th");
        idHeader.textContent("id");
        row.appendChild(idHeader);
        
        /*
        nameHeader = document.createElement("th");
        nameHeader.textContent("name");
        row.appendChild(nameHeader);
        
        descriptionHeader = document.createElement("th");
        descriptionHeader.textContent("description");
        row.appendChild(descriptionHeader);
        
        usernameHeader = document.createElement("th");
        usernameHeader.textContent("username");
        row.appendChild(usernameHeader);
        
        imageHeader = document.createElement("th");
        imageHeader.textContent("image");
        row.appendChild(imageHeader);
        
        priceHeader = document.createElement("th");
        priceHeader.textContent("price");
        row.appendChild(priceHeader);
        */
        
        thead.appendChild(row);
        table.appendChild(thead);
        
        //building tbody
        tbody = document.createElement("tbody");
        entry.value.forEach(function (item) {
			bodyRow = document.createElement("tr");
			
			idCell = document.createElement("td");
        	idCell.textContent(item.id_code);
        	bodyRow.appendChild(idCell);
        	
        	/*
        	nameCell = document.createElement("td");
        	nameCell.textContent(item.name);
        	bodyRow.appendChild(nameCell);
        	
        	descriptionCell = document.createElement("td");
        	descriptionCell.textContent(item.description);
        	bodyRow.appendChild(descriptionCell);
        	
        	usernameCell = document.createElement("td");
        	usernameCell.textContent(item.username);
        	bodyRow.appendChild(usernameCell);
        	
        	imageCell = document.createElement("td");
        	imageCell.textContent(item.image);
        	bodyRow.appendChild(imageCell);
        	
        	priceCell = document.createElement("td");
        	priceCell.textContent(item.price);
        	bodyRow.appendChild(priceCell);
        	*/
        	
        	tbody.appendChild(bodyRow);
		});
		//connect everything
		table.appendChild(tbody);
		bulletPoint.appendChild(table);
        self.winningAuctionBulletList.appendChild(table);
      });
	}
}


function BuyingAuctionsTable(_buyingAuctionsContainer, _buyingAuctionsContainerBody) {
    this.buyingAuctionsContainer = _buyingAuctionsContainer;
    this.buyingAuctionsContainerBody = _buyingAuctionsContainerBody;

    this.show = function() {
      let self = this; // this not direcly visible in nested functions,
      // need to copy it in a local variable
      makeCall("GET", "LoadBuyingAuctions", null,
        function(req) { // callback of the GET request
          if (req.readyState === 4) {
            if (req.status === 200) {
              let buyingAuctionsToShow = JSON.parse(req.responseText);
              if (buyingAuctionsToShow.length === 0) {
                buyingAuctionsAlert.textContent = "No auctions yet!";
                return;
              }
              self.update(buyingAuctionsToShow); // self visible by closure, view status has topic ID as parameter
            } else { //printing errors
              buyingAuctionsAlert.textContent = req.responseText;
            }
          }
        }
      );
    };

    this.update = function(buyingAuctionsToShow) {
      let row;
      let idCodeCell;
      let minimumOffsetCell;
      let currentBidCell;
      let linktext;
      let anchor;
      let exp_dateCell;
      this.buyingAuctionsContainerBody.innerHTML = ""; // empty the table body
      // build updated list
      let self = this; //  nested function updates the object bound to this, which is not visible directly
      buyingAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure
        
        row = document.createElement("tr");
        
        idCodeCell = document.createElement("td");
        idCodeCell.textContent = auction.id_code;
        //anchor.setAttribute("topicid", topic.id);
        row.appendChild(idCodeCell);
        
        //idCodeCell.addEventListener("click", getBiddingPage, false);
        
        minimumOffsetCell = document.createElement("td");
        minimumOffsetCell.textContent = auction.minimum_offset;
        row.appendChild(minimumOffsetCell);
        
        currentBidCell = document.createElement("td");
        currentBidCell.textContent = auction.current_bid;
        row.appendChild(currentBidCell);
        
        exp_dateCell = document.createElement("td");
        exp_dateCell.textContent = auction.expiry_date_time;
        row.appendChild(exp_dateCell);
        
        
        self.buyingAuctionsContainerBody.appendChild(row);
      });
    };
}
/*function WinningAuctionsTable(_winningAuctionsContainer, _winningAuctionsContainerBody) {
    this.winningAuctionsContainer = _winningAuctionsContainer;
    this.winningAuctionsContainerBody = _winningAuctionsContainerBody;

    this.show = function() {
      let self = this; // this not direcly visible in nested functions,
      // need to copy it in a local variable
      makeCall("GET", "LoadWinningAuctionsTable", null,
        function(req) { // callback of the GET request
          if (req.readyState === 4) {
            if (req.status === 200) {
              let winningAuctionsToShow = JSON.parse(req.responseText);
              if (winningAuctionsToShow.length === 0) {
                winningAuctionsAlert.textContent = "You are not winning any auction, keep offering!";
                return;
              }
              self.update(winningAuctionsToShow); // self visible by closure, view status has topic ID as parameter
            } else { //printing errors
              winningAuctionsAlert.textContent = req.responseText;
            }
          }
        }
      );
    };

    this.update = function(winningAuctionsToShow) {
      let row;
      let idCodeCell;
      let currentBidCell;
      this.winningAuctionsContainerBody.innerHTML = ""; // empty the table body
      // build updated list
      let self = this; //  nested function updates the object bound to this, which is not visible directly
      winningAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure
        
        row = document.createElement("tr");
        
        idCodeCell = document.createElement("td");
        idCodeCell.textContent = auction.id_code;
        //anchor.setAttribute("topicid", topic.id);
        row.appendChild(idCodeCell);
        
        //idCodeCell.addEventListener("click", getBiddingPage, false);
        
        currentBidCell = document.createElement("td");
        currentBidCell.textContent = auction.current_bid;
        row.appendChild(currentBidCell);
        
        self.winningAuctionsContainerBody.appendChild(row);
      });
    };
}/*
/*function WonAuctionsTable(_wonAuctionsContainer, _wonAuctionsContainerBody) {
    this.wonAuctionsContainer = _wonAuctionsContainer;
    this.wonAuctionsContainerBody = _wonAuctionsContainerBody;

    this.show = function() {
      let self = this; // this not direcly visible in nested functions,
      // need to copy it in a local variable
      makeCall("GET", "LoadWonAuctions", null,
        function(req) { // callback of the GET request
          if (req.readyState === 4) {
            if (req.status === 200) {
              let wonAuctionsToShow = JSON.parse(req.responseText);
              if (wonAuctionsToShow.length === 0) {
                wonAuctionsAlert.textContent = "No auctions won yet, keep bidding!";
                return;
              }
              self.update(wonAuctionsToShow); // self visible by closure, view status has topic ID as parameter
            } else { //printing errors
              wonAuctionsAlert.textContent = req.responseText;
            }
          }
        }
      );
    };

    this.update = function(wonAuctionsToShow) {
      let row;
      let idCodeCell;
      let minimumOffsetCell;
      let currentBidCell;
      let exp_dateCell;
      this.wonAuctionsContainerBody.innerHTML = ""; // empty the table body
      // build updated list
      let self = this; //  nested function updates the object bound to this, which is not visible directly
      wonAuctionsToShow.forEach(function(auction) { // self visible in nested function by closure
        
        row = document.createElement("tr");
        
        idCodeCell = document.createElement("td");
        idCodeCell.textContent = auction.id_code;
        //anchor.setAttribute("topicid", topic.id);
        row.appendChild(idCodeCell);
        
        idCodeCell.addEventListener("click", getBiddingPage, false);
        
        minimumOffsetCell = document.createElement("td");
        minimumOffsetCell.textContent = auction.minimum_offset;
        row.appendChild(minimumOffsetCell);
        
        currentBidCell = document.createElement("td");
        currentBidCell.textContent = auction.current_bid;
        row.appendChild(currentBidCell);
        
        exp_dateCell = document.createElement("td");
        exp_dateCell.textContent = auction.expiry_date_time;
        row.appendChild(exp_dateCell);
        
        
        self.wonAuctionsContainerBody.appendChild(row);
      });
    };
}*/


} //closing visibility block