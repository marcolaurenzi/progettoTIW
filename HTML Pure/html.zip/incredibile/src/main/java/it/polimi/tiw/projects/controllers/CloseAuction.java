package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.exceptions.AuctionException;
import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.beans.User;

/**
 * Servlet implementation class CloseAuction
 */
@WebServlet("/CloseAuction")
public class CloseAuction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CloseAuction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer id_code = null;
		AuctionDAO auctionDao = new AuctionDAO(connection);
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute("user");
		String errorPath = "/GoToErrorPage";
		String errorMessage;
		
		try {
			String toParse = request.getParameter("auctionId");
			id_code = Integer.parseInt(toParse);
		}
		catch (Exception e){
			errorMessage = "auctionId not valid";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		}
		
		try {
			if(!auctionDao.findAllExpiredAuctionsId(user).contains(id_code)) {
				throw new AuctionException();
			}
			
		}catch (AuctionException e) {
			errorMessage = "this auction doesn't exist or is not your's, you can't close it";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		} catch (SQLException e) {
			errorMessage = "db error";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		}
		
		
		auctionDao.closeAuction(id_code);
		
		String path = getServletContext().getContextPath() + "/Selling";
		response.sendRedirect(path);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
