package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.connection.ConnectionHandler;

import it.polimi.tiw.projects.exceptions.ParameterException;

/**
 * Servlet implementation class CreateArticle
 */
@WebServlet("/CreateArticle")
@MultipartConfig
public class CreateArticle extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateArticle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id_code = 0;
		String name = null;
		String path = null;
		String username = null;
		String description = null;
		String toParsePrice = null;
		float price;
		User user;
		InputStream imageStream = null;
		String mimeType = null;
		String errorMessage;
		String errorPath = "/GoToErrorPage";

		
		
		Part imagePart = request.getPart("image");
		
		// if the image is not null
		if (imagePart != null && imagePart.getSize() > 0) {
			imageStream = imagePart.getInputStream();
			String filename = imagePart.getSubmittedFileName();
			mimeType = getServletContext().getMimeType(filename);			
		}
        
		name = (String) request.getParameter("name");
		description = (String) request.getParameter("description");
		toParsePrice = (String) request.getParameter("price");
		
		user = (User) request.getSession().getAttribute("user");
		
		// check if required values are missing
		try {
			price = Float.parseFloat(toParsePrice);
			if(name == null || name.equals("") || price < 0 || toParsePrice == null || !mimeType.startsWith("image/")) {
				throw new ParameterException();
			}
		}
		catch (ParameterException e) {
			errorMessage = "parameters incomplete or wrong";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		}

		//insert the new user in the DB
		ItemDAO itemDao = new ItemDAO(connection);
		try {
			id_code = itemDao.getNextIdCode();
			username = user.getUsername();
			itemDao.createItem(id_code + 1, username, name, description, imageStream, price, true);
		} catch (SQLException e) {
			errorMessage = "db error in the creation of the item";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		}
		finally {
			// Redirect to the main Selling page
			path = getServletContext().getContextPath() + "/Selling";
			response.sendRedirect(path);
		}
	}

}
