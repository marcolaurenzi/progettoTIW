package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.BidDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class CreateBid
 */
@WebServlet("/CreateBid")
public class CreateBid extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public CreateBid() {
		super();
	}
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute("user");
		BidDAO bidDAO = new BidDAO(connection);
		AuctionDAO auctionDAO = new AuctionDAO(connection);
		int auctionId = 0;
		float amount = 0;
		String path = "/GoToBiddingPage";
		boolean flag = false;
		float highestBid = 0;
		float minimumOffset = 0;
		String errorMsg = "";
		Auction auction;
		
		//controllo che ci siano entrambi i parametri
		try {
			auctionId = Integer.parseInt(request.getParameter("auctionId"));
			amount = Float.parseFloat(request.getParameter("amount"));
		}catch (Exception e) {
			e.printStackTrace();
			//send error message: invalid parameters that recharges the page
			return;
		}
		
		//controlla che auctionId esista nella lista delle aste aperte prima di creare un'offerta per quello
		try {
			flag = auctionDAO.containsInOpenAuctions(auctionId);
	
		} catch (SQLException SQLe) {
			SQLe.printStackTrace ();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, SQLe.getMessage() + "Error in the DB");
			return;
		}
		
		//controllo che amount sia un valore valido
		try {
			highestBid = bidDAO.getHighestBid(auctionId);
		} catch (SQLException e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage() + "Error in the DB");
			return;
		}
		auction = auctionDAO.getAuctionDetails(auctionId);
		if (highestBid == 0) {
			highestBid = auction.getCurrent_Price();
		}
		minimumOffset = auction.getMinimum_Offset();
		
		//controllo che l'username di chi fa l'offerta debba essere diverso da quello di chi ha creato l'asta? 
				
		try {
			if (flag && highestBid + minimumOffset < amount) {
				bidDAO.createBid (user.getUsername(), auctionId, amount);
			}
			else if (!flag) {
				
				System.out.println ("invalid auctionId");
				//invalid auction ID
				errorMsg = "invalid auction id";
			}
			else {
				//invalid amount
				System.out.println ("invalid amount");
				errorMsg = "invalid amount";
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage() + "Error in the DB");
			return;
		}
		
		String path2 = getServletContext().getContextPath() + path+ "?auctionId=" + auctionId + "&errorMsg=" + errorMsg;
		response.sendRedirect(path2);
	}
}
