package it.polimi.tiw.projects.utils;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;

public class Utils {
	
	public static String computeLeftTime(LocalDateTime time_left, Timestamp timestamp) {
		
		Period period = Period.between(time_left.toLocalDate(), timestamp.toLocalDateTime().toLocalDate());
		Duration duration = Duration.between(time_left, timestamp.toLocalDateTime());
	
		int days = period.getDays();
		
		long hours = duration.toHours() % 24;
		long minutes = duration.toMinutes() % 60;
		long seconds = duration.toSeconds() % 60;

		MissingTime missingTime = new MissingTime(days, hours, minutes, seconds);
		
		return missingTime.toString();
		
	}

}
