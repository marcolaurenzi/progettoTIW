package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class OpenAuction
 */
@WebServlet("/OpenAuction")
public class OpenAuction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OpenAuction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = null;
		String path = null;
		String auctionToParse;
		int auctionId;
		ItemDAO itemDao = new ItemDAO(connection);
		AuctionDAO auctionDao = new AuctionDAO(connection);
		
		try {
			
			// lettura username
			user = (User) request.getSession().getAttribute("user");
			
			auctionToParse = request.getParameter("toOpen");
			
			auctionId = Integer.parseInt(auctionToParse);    
			
			// se nessun item fa parte dell'asta non si può creare
			if(itemDao.getItems(auctionId).isEmpty()) {
				throw new Exception("You can't open an empty auction");
			}
			
			// non puoi aprire un'asta chiusa o scaduta oppure un'asta non di tua proprietà
	        if(!auctionDao.findAllToOpenAuctionId(user).contains(auctionId)) {
	        	throw new Exception("You can only open your auctions");
	        }
			
			if (user == null) {
				throw new Exception("invalid user");
			}

		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incomplete informations");
			return;
		}

		try {
			auctionDao.openAuction(auctionId);
		} catch (SQLException e) {
				e.printStackTrace();
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Db error in the registration");
				return;
		}
		finally {
			path = getServletContext().getContextPath() + "/Selling";
			response.sendRedirect(path);
		}
	}

}
