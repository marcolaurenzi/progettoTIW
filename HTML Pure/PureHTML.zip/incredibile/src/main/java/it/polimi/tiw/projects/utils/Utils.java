package it.polimi.tiw.projects.utils;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;

public class Utils {
	
	public static String computeLeftTime(LocalDateTime loginTime, Timestamp timestamp) {
		
		Period period = Period.between(loginTime.toLocalDate(), timestamp.toLocalDateTime().toLocalDate());
		Duration duration = Duration.between(loginTime, timestamp.toLocalDateTime());
	
		int years = period.getYears();
		int months = years*12 + period.getMonths();
		int days = months*30 + period.getDays();
		
		long hours = duration.toHours() % 24;
		long minutes = duration.toMinutes() % 60;
		long seconds = duration.toSeconds() % 60;

		MissingTime missingTime = new MissingTime(days, hours, minutes, seconds);
		
		return missingTime.toString();
		
	}

}
