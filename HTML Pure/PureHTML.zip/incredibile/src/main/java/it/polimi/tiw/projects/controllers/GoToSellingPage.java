package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.beans.Item;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class GoToSellingPage
 */
@WebServlet("/Selling")
public class GoToSellingPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	private Connection connection;
       
    
    public GoToSellingPage() {
        super();
    }
    
    public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		LocalDateTime loginTime = (LocalDateTime) session.getAttribute("time");
		if (session == null || session.getAttribute("user") == null) {
			String path = getServletContext().getContextPath();
			response.sendRedirect(path);
		}
		else {
			AuctionDAO auctionDao = new AuctionDAO(connection);
			ItemDAO itemDao = new ItemDAO(connection);
			
			Map<Auction, User> closedAuctions = new HashMap<Auction, User>();
			List<Auction> openedAuctions = new ArrayList<Auction>();
			List<Auction> createdAuctions = new ArrayList<Auction>();
			List<Auction> toOpenAuctions = new ArrayList<Auction>();
			List<Item> items = new ArrayList<Item>();
			
			
			
			List<Auction> expiredAuctions = new ArrayList<Auction>();
			List<Float> finalPrices = new ArrayList<Float>();
			try {
				openedAuctions = auctionDao.findAllOpenedAuctions((User)request.getSession().getAttribute("user"), loginTime);
				
				expiredAuctions = auctionDao.findAllExpiredAuctions((User)request.getSession().getAttribute("user"));
				closedAuctions = auctionDao.findAllClosedAuctions((User)request.getSession().getAttribute("user"));
				toOpenAuctions = auctionDao.findAllToOpenAuctions((User)request.getSession().getAttribute("user"));
				items = itemDao.findAllAvailableItemsAuctions((User)request.getSession().getAttribute("user"));
				for(Auction a : closedAuctions.keySet()) {
					finalPrices.add(auctionDao.getTotalValue(a.getId_Code()));
				}
			} catch(SQLException e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage() + "Error in the DB");
				return;
			}
			
			ServletContext servletContext = getServletContext();
			final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
			ctx.setVariable("expiredAuctions", expiredAuctions);
			ctx.setVariable("openedAuctions", openedAuctions);
			ctx.setVariable("closedAuctions", closedAuctions);
			ctx.setVariable("finalPrices", finalPrices);
			ctx.setVariable("createdAuctions", createdAuctions);
			ctx.setVariable("toOpenAuctions", toOpenAuctions);
			ctx.setVariable("items", items);
			String path = "/WEB-INF/SellingPage.html";
			templateEngine.process(path, ctx, response.getWriter());
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
