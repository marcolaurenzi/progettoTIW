package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.DAO.*;
import it.polimi.tiw.projects.beans.*;
import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.exceptions.*;

/**
 * Servlet implementation class CreateArticle
 */
@WebServlet("/CreateAuction")
public class CreateAuction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
    
    public CreateAuction() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id_code = 0;
		User user = null;
		String path = null;
		LocalDateTime expiry_date_time = null;
		float minimum_offset;
		AuctionDAO auctionDao = new AuctionDAO(connection);
		String errorMessage;
		String errorPath = "/GoToErrorPage";
		String datetimeString = null;
		String rise = null;
		
		try {
			
			// lettura data e ora
			datetimeString = request.getParameter("expiry_date_time");
			// lettura offset
			rise = request.getParameter("minimum_offset");
			if(datetimeString == null || rise == null) {
				throw new ParameterException();
			}
			// lettura username
			user = (User) request.getSession().getAttribute("user");
			if(user == null) {
				throw new UserException();
			}
			// conversione
			expiry_date_time = LocalDateTime.parse(datetimeString, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			// conversione
			minimum_offset = Float.parseFloat(rise);
			if (minimum_offset <= 0) {
				throw new ParameterException();
			}
			if(expiry_date_time.isBefore(LocalDateTime.now())) {
				throw new DateTimeException();
			}
		
		} catch (UserException e) {
			errorMessage = "invalid user";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		} catch(ParameterException e) {
			errorMessage = "incomplete informations";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		} catch(DateTimeException e) {
			errorMessage = "incorrect expiry date and time";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		}

		//insert the new auction in the DB
		try {
			id_code = auctionDao.getNextIdCode();
			auctionDao.createAuction(id_code + 1, user.getUsername(), expiry_date_time, minimum_offset);
		} catch (SQLException e) {
			errorMessage = "DB Error, try again";
			String path2 = getServletContext().getContextPath() + errorPath + "?errorMessage=" + errorMessage;
			response.sendRedirect(path2);
			return;
		}
		finally {
			path = getServletContext().getContextPath() + "/Selling";
			response.sendRedirect(path);
		}
	}	

}
