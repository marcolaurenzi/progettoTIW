package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.DAO.BidDAO;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class CreateBid
 */
@WebServlet("/CreateBid")
public class CreateBid extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public CreateBid() {
		super();
	}
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute("user");
		BidDAO bidDAO = new BidDAO(connection);
		int auctionId = 0;
		float amount = 0;
		String path = "/GoToBiddingPage";
		
		//aggiungere il controllo dell'amount
		try {
			auctionId = Integer.parseInt(request.getParameter("auctionId"));
			amount = Float.parseFloat(request.getParameter("amount"));
		}catch (Exception e) {
			e.printStackTrace();
			//send error message: invalid parameters that recharges the page
			return;
		}
		
		//controlla che auctionId esista prima di creare un'offerta per quello
		
		try {
			bidDAO.createBid (user.getUsername(), auctionId, amount);
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
		
		String path2 = getServletContext().getContextPath() + path+ "?auctionId=" + auctionId;
		response.sendRedirect(path2);
	}
}
