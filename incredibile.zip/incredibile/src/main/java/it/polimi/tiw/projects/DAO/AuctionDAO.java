package it.polimi.tiw.projects.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;

public class AuctionDAO {

	private Connection connection;
	private String username;
		
	public AuctionDAO(Connection connection) {
		this.connection = connection;
	}
		
	public AuctionDAO(Connection connection, String username) {
		this.connection = connection;
		this.username = username;
	}
	
	public void createAuction(String auctionId, String username, String expiringTime, String expiringDate, double minimumRise, double initialPrice) throws SQLException {
		String query = "INSERT into Auctions (auctionId, username, expiringTime, expiringDate, minimumRise, initialPrice) VALUES(?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setString(1, auctionId);
			pstatement.setString(2, username);
			pstatement.setString(3, expiringTime);
			pstatement.setString(4, expiringDate);
			pstatement.setDouble(5, minimumRise);
			pstatement.setDouble(6, initialPrice);
			pstatement.executeUpdate();  // what does it returns??
		}
	}
}
