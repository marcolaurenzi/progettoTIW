package it.polimi.tiw.projects.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import it.polimi.tiw.projects.beans.Item;

public class OfferDAO {
	
	private Connection connection;
	
	public OfferDAO(Connection connection) {
		this.connection = connection;
	}
	
	public Float getHighestOffer(int id_code) throws SQLException {
		Float toRet = null;
		String query ="SELECT MAX(amount) FROM bid WHERE auction_id = ?";
		try (PreparedStatement pstatement = connection.prepareStatement(query)) {
			pstatement.setInt(1, id_code);
			try (ResultSet result = pstatement.executeQuery()) {
				if (result.next()) {
					toRet = result.getFloat(1);
				}
			}
		}
		return toRet;
	}

}
