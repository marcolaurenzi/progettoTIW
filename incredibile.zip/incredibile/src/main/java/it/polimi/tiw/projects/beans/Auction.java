package it.polimi.tiw.projects.beans;

import java.sql.Time;
import java.sql.Date;

public class Auction {
	
	private int auctionId;
	private String username;
	private String expiringDate;
	private String expiringTime;
	private float minimumRise;
	private float initialPrice;
	
	private int getAuctionId() {
		return this.auctionId;
	}
	private String getUsername() {
		return this.username;
	}
	
	private String getExpiringDate() {
		return this.expiringDate;
	}
	
	private String getExpiringTime() {
		return this.expiringTime;
	}
	
	private float getMinimumRise() {
		return this.minimumRise;
	}
	
	private float getInitialPrice() {
		return this.initialPrice;
	}
	
	private void getAuctionId(int id) {
		this.auctionId = id;
	}
	private void  getUsername(String username) {
		this.username = username;
	}
	
	private void setExpiringDate(String date) {
		this.expiringDate = date;
	}
	
	private void setExpiringTime(String time) {
		this.expiringTime = time;
	}
	
	private void setMinimumRise(float price) {
		this.minimumRise = price;
	}
	
	private void setInitialPrice(float price) {
		this.initialPrice = price;
	}

}
