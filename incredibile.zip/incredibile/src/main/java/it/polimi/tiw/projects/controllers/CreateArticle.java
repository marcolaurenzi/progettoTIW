package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class CreateArticle
 */
@WebServlet("/CreateArticle")
@MultipartConfig
public class CreateArticle extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateArticle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id_code = 0;
		String name = null;
		String path = null;
		String username = null;
		String description = null;
		String toParsePrice = null;
		float price;
		User user;
		
		Part imagePart = request.getPart("image");
		
		InputStream imageStream = null;
		String mimeType = null;
		if (imagePart != null) {
			imageStream = imagePart.getInputStream();
			String filename = imagePart.getSubmittedFileName();
			mimeType = getServletContext().getMimeType(filename);			
		}
		
		
		try {
            
			name = (String) request.getParameter("name");
			description = (String) request.getParameter("description");
			toParsePrice = (String) request.getParameter("price");
			price = Float.parseFloat(toParsePrice);
			user = (User) request.getSession().getAttribute("user");
			
			if (name == null || name.equals("") || imageStream == null || (imageStream.available()==0) || !mimeType.startsWith("image/")) {
				response.sendError(505, "Parameters incomplete");
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incomplete informations");
			return;
		}

		//insert the new user in the DB
		ItemDAO itemDao = new ItemDAO(connection);
		try {
			id_code = itemDao.getNextIdCode();
			username = user.getUsername();
			itemDao.createItem(id_code + 1, username, name, description, imageStream, price, true);
		} catch (SQLException e) {
				e.printStackTrace();
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Db error in the registration");
		}
		finally {
			// Redirect to the main Selling page
			path = getServletContext().getContextPath() + "/Selling";
			response.sendRedirect(path);
		}
	}

}
