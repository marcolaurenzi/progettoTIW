package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.GregorianCalendar;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.DAO.*;
import it.polimi.tiw.projects.beans.*;
import it.polimi.tiw.projects.connection.ConnectionHandler;

/**
 * Servlet implementation class CreateArticle
 */
@WebServlet("/CreateAuction")
public class CreateAuction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAuction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	// todo non so perchè non crea la tupla nel db
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id_code = 0;
		User user = null;
		String path = null;
		LocalDateTime expiry_date_time = null;
		float minimum_offset;
		String itemsToParse;
		ItemDAO itemDao = new ItemDAO(connection);
		
		
		try {
			
			// lettura data e ora
			String datetimeString = request.getParameter("expiry_date_time");
			// conversione
			expiry_date_time = LocalDateTime.parse(datetimeString, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			// lettura offset
			String rise = request.getParameter("minimum_offset");
			// conversione
			minimum_offset = Float.parseFloat(rise);
			// lettura username
			user = (User) request.getSession().getAttribute("user");
			itemsToParse = request.getParameter("articles");
			
			// Parsing the string into a list of items
			String[] intArray = itemsToParse.split("\\s+"); // Split the string based on whitespace
	        List<Item> items = new ArrayList<>();
	        
	        for (String num : intArray) {
	        	Item i = itemDao.getItem(Integer.parseInt(num));
	            items.add(i);
	        }
	        
	        
			if (user == null) {
				throw new Exception("invalid user");
			}

		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incomplete informations");
			return;
		}

		//insert the new user in the DB
		AuctionDAO auctionDao = new AuctionDAO(connection);
		try {
			id_code = auctionDao.getNextIdCode();
			// todo togliere availabilty agli item selezionati
			auctionDao.createAuction(id_code + 1, user.getUsername(), expiry_date_time, minimum_offset);
		} catch (SQLException e) {
				e.printStackTrace();
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Db error in the registration");
				return;
		}
		finally {
			path = getServletContext().getContextPath() + "/Selling";
			response.sendRedirect(path);
		}
	}	

}
