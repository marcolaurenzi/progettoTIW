package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.DAO.AuctionDAO;
import it.polimi.tiw.projects.DAO.ItemDAO;
import it.polimi.tiw.projects.DAO.OfferDAO;
import it.polimi.tiw.projects.beans.Auction;
import it.polimi.tiw.projects.beans.Item;
/**
 * Servlet implementation class GoToAuctionDetails
 */
@WebServlet("/GoToAuctionDetails")
public class GoToAuctionDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	private Connection connection;
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
		connection = ConnectionHandler.getConnection(getServletContext());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GoToAuctionDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String auctionId = request.getParameter("auctionId");
		
		AuctionDAO auctionDao = new AuctionDAO(connection);
		ItemDAO itemDao = new ItemDAO(connection);
		OfferDAO offerDao = new OfferDAO(connection);
		
		Float highestOffer;
		Float totalValue;
		Auction auction = null;
		List<Item> items = new ArrayList<Item>();
		
		try {
			auction = auctionDao.getAuctonDetails(Integer.parseInt(auctionId));
			items = itemDao.getItems(Integer.parseInt(auctionId));
			highestOffer = offerDao.getHighestOffer(Integer.parseInt(auctionId));
			totalValue = auctionDao.getTotalValue(Integer.parseInt(auctionId));
		} catch(SQLException e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage() + "Error in the DB");
			return;
		}
		
		// processing the page
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("auction", auction);
		ctx.setVariable("items", items);
		ctx.setVariable("highestOffer", highestOffer);
		ctx.setVariable("totalValue", totalValue);
		String path = "/AuctionDetails.html";
		templateEngine.process(path, ctx, response.getWriter());
		
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
