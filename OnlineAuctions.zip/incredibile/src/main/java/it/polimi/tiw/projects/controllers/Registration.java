package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.connection.ConnectionHandler;
import it.polimi.tiw.projects.DAO.UserDAO;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
    private TemplateEngine templateEngine;
    
    
    public Registration() {
        super();
    }
    
    /**
     * creates a connection to the db using the utility class Connection Handler
     * sets up the Thymeleaf Template Engine
     */
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect(getServletContext().getContextPath() + "/signup.html");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// obtain parameters and check validity
				String username = null;
				String password = null;
				String address = null;
				String path;
				
				try {
					username = StringEscapeUtils.escapeJava(request.getParameter("username"));
					password = StringEscapeUtils.escapeJava(request.getParameter("password"));
					address = StringEscapeUtils.escapeJava(request.getParameter("address"));
							
				if (username == null || password == null || address == null ||
						username.isBlank() || password.isBlank() || address.isBlank()) {
					throw new Exception("incomplete or empty informations");
				}

				} catch (Exception e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incomplete informations");
					return;
				}

				//insert the new user in the DB
				UserDAO userDao = new UserDAO(connection);
				try {
					userDao.createUser(username, password, address);
				} catch (SQLException e) {
						response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Db error in the registration");
						return;
				}
				//redirect to login page
				path = getServletContext().getContextPath() + "/index.html";
				response.sendRedirect(path);
	}
	
	public void destroy() {
		try {
			ConnectionHandler.closeConnection(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
