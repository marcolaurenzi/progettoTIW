package it.polimi.tiw.projects.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import it.polimi.tiw.projects.beans.User;

public class UserDAO {
	private Connection connection;
	
	public UserDAO(Connection connection) {
		this.connection = connection;
	}
	
	public void createUser (String username, String password, String address) throws SQLException{
		String query = "INSERT into user (username, password, address) VALUES(?, ?, ?)";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setString(1, username);
			pstatement.setString(2, password);
			pstatement.setString(3, address);
			pstatement.executeUpdate();  // what does it returns??
		}
	}

	public User checkCredentials(String username, String password) throws SQLException {
		String query = "SELECT username, address FROM user  WHERE username = ? AND password =?";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setString(1, username);
			pstatement.setString(2, password);
			try (ResultSet result = pstatement.executeQuery();) {
				System.out.println("second try");
				if (!result.isBeforeFirst()) // no results, credential check failed
					return null;
				else {
					result.next();
					User user = new User();
					user.setUsername(result.getString("username"));
					user.setAddress(result.getString("address"));
					return user;
				}
			}catch (Exception E) {
				System.out.println("second try");
				throw new SQLException("second try");
			}
		}catch (Exception e) {
			System.out.println("first try");
			throw new SQLException("first try");
		}
	}

}
